Compile Insertion Sort and Merge Sort by using the following commands on the windows command prompt:
  
  javac InsertionSort.java
  javac MergeSort.java

Afterwards, run the program by using:

  java InsertionSort
  java MergeSort

Running these programs will print the length and count of each parsing each file through Insertion Sort and Merge Sort.
Do table and analysis are inside the excel file "Sorts - Time Complexity(Graph).xlsx"
